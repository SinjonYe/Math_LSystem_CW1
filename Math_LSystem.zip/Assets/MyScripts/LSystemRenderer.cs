using UnityEngine;
using System.Collections.Generic;

public class LSystemRenderer : MonoBehaviour
{
    public GLLineRenderer glRenderer;

    public float angleRandomRange = 0f;  //  ����Ƕȷ�Χ��degree��

    struct TurtleState
    {
        public Vector3 pos;
        public Quaternion rot;

        public TurtleState(Vector3 p, Quaternion r)
        {
            pos = p;
            rot = r;
        }
    }

    public void Draw(string instructions, float step, float angle)
    {
        glRenderer.Clear();

        Stack<TurtleState> stack = new Stack<TurtleState>();

        Vector3 pos = Vector3.zero;
        Quaternion rot = Quaternion.Euler(0, 0, 90); // ����

        foreach (char c in instructions)
        {
            if (c == 'F')
            {
                Vector3 newPos = pos + rot * Vector3.right * step;
                glRenderer.AddLine(pos, newPos);
                pos = newPos;
            }
            else if (c == '+')
            {
                float rand = Random.Range(-angleRandomRange, angleRandomRange);
                rot *= Quaternion.Euler(0, 0, angle + rand);
            }
            else if (c == '-')
            {
                float rand = Random.Range(-angleRandomRange, angleRandomRange);
                rot *= Quaternion.Euler(0, 0, -(angle + rand));
            }
            else if (c == '[')
            {
                stack.Push(new TurtleState(pos, rot));
            }
            else if (c == ']')
            {
                var st = stack.Pop();
                pos = st.pos;
                rot = st.rot;
            }
        }

        glRenderer.transform.rotation = Quaternion.identity;
    }
}
