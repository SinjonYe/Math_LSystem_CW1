using System.IO;
using System.Collections.Generic;
using UnityEngine;

public class LSystemController : MonoBehaviour
{
    public LSystemGenerator generator;
    public LSystemRenderer lsystemRenderer;

    public int iterations = 5;
    public float angleOffset = 0f;
    public float randomAngleRange = 0f;   // ����������Ƕȷ�Χ
    public float stepScale = 1f;

    public int CurrentPlant { get; private set; } = 1;

    private string folder;
    private LSystemConfig currentConfig;

    public float BaseAngle => currentConfig != null ? currentConfig.angle : 0f;
    public float CurrentAngle => BaseAngle + angleOffset;

    private LSystemUI ui;

    void Start()
    {
        folder = Application.streamingAssetsPath;

        ui = FindFirstObjectByType<LSystemUI>();

        LoadAndDraw(1);
    }

    void Update()
    {
        HandleKeyboard();
    }

    void HandleKeyboard()
    {
        // Q �л� Plant
        if (Input.GetKeyDown(KeyCode.Q))
        {
            int next = CurrentPlant + 1;
            if (next > 8) next = 1;
            LoadAndDraw(next);
        }

        // �� �� ��������
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            iterations++;
            Redraw();
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            iterations = Mathf.Max(1, iterations - 1);
            Redraw();
        }

        // �� �� �Ƕ� offset
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            angleOffset -= 2f;
            Redraw();
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            angleOffset += 2f;
            Redraw();
        }

        // PageUp / PageDown = ����Ƕȷ�Χ
        if (Input.GetKeyDown(KeyCode.PageUp))
        {
            randomAngleRange += 1f;
            Redraw();
        }
        if (Input.GetKeyDown(KeyCode.PageDown))
        {
            randomAngleRange = Mathf.Max(0f, randomAngleRange - 1f);
            Redraw();
        }
    }

    public void LoadAndDraw(int index)
    {
        CurrentPlant = index;

        string file = Path.Combine(folder, $"plant{index}.json");
        string json = File.ReadAllText(file);

        currentConfig = JsonUtility.FromJson<LSystemConfig>(json);

        angleOffset = 0;

        Redraw();
        ui.RefreshUI();
    }

    public void Redraw()
    {
        if (currentConfig == null) return;

        var rules = currentConfig.rules.ToDict();
        string result = generator.Generate(currentConfig.axiom, rules, iterations);

        float finalStep = currentConfig.step * stepScale;

        //  ������Ƕȷ�Χ���� Renderer
        lsystemRenderer.angleRandomRange = randomAngleRange;

        lsystemRenderer.Draw(
            result,
            finalStep,
            CurrentAngle
        );

        ui?.RefreshUI();
    }
}

[System.Serializable]
public class LSystemConfig
{
    public string axiom;
    public float angle;
    public float step;
    public Rule[] rules;
}

[System.Serializable]
public class Rule
{
    public string key;
    public string value;
}

public static class RuleExt
{
    public static Dictionary<string, string> ToDict(this Rule[] rules)
    {
        var dict = new Dictionary<string, string>();
        foreach (var r in rules) dict[r.key] = r.value;
        return dict;
    }
}
