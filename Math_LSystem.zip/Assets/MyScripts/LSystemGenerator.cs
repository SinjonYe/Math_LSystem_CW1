using System.Collections.Generic;
using UnityEngine;

public class LSystemGenerator : MonoBehaviour
{
    public string Generate(string axiom, Dictionary<string, string> rules, int iterations)
    {
        string current = axiom;

        for (int i = 0; i < iterations; i++)
        {
            string next = "";

            foreach (char c in current)
            {
                string s = c.ToString();
                next += rules.ContainsKey(s) ? rules[s] : s;
            }

            current = next;
        }

        return current;
    }
}
