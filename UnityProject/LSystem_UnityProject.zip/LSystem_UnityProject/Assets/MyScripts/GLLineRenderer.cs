using UnityEngine;
using System.Collections.Generic;

public class GLLineRenderer : MonoBehaviour
{
    public Material lineMaterial;
    public List<Vector3[]> lines = new List<Vector3[]>();

    void OnRenderObject()
    {
        if (lineMaterial == null)
            return;

        lineMaterial.SetPass(0);

        GL.PushMatrix();
        GL.MultMatrix(transform.localToWorldMatrix);

        GL.Begin(GL.LINES);
        GL.Color(Color.black);

        foreach (var segment in lines)
        {
            GL.Vertex(segment[0]);
            GL.Vertex(segment[1]);
        }

        GL.End();
        GL.PopMatrix();
    }

    public void Clear()
    {
        lines.Clear();
    }

    public void AddLine(Vector3 start, Vector3 end)
    {
        lines.Add(new Vector3[] { start, end });
    }
}
