using UnityEngine;

public class CameraAutoFit : MonoBehaviour
{
    public Camera cam;
    public GLLineRenderer renderer;
    public float padding = 1.2f;

    void LateUpdate()
    {
        if (renderer.lines.Count == 0) return;

        // Find bounds
        Vector3 min = renderer.lines[0][0];
        Vector3 max = renderer.lines[0][0];

        foreach (var seg in renderer.lines)
        {
            Vector3 a = seg[0];
            Vector3 b = seg[1];

            min = Vector3.Min(min, a);
            min = Vector3.Min(min, b);
            max = Vector3.Max(max, a);
            max = Vector3.Max(max, b);
        }

        Vector3 center = (min + max) / 2f;
        float height = max.y - min.y;

        // Move camera
        cam.transform.position = new Vector3(center.x, center.y, -10f);

        // Adjust orthographic size
        cam.orthographic = true;
        cam.orthographicSize = height * 0.5f * padding;
    }
}
