using UnityEngine;
using TMPro;

public class LSystemUI : MonoBehaviour
{
    public LSystemController controller;

    public TextMeshProUGUI plantText;
    public TMP_InputField iterationInput;
    public TMP_InputField angleInput;
    public TMP_InputField randomAngleInput;   //  ����
    public TMP_InputField stepInput;

    void Start()
    {
        RefreshUI();
    }

    public void RefreshUI()
    {
        if (controller == null) return;

        plantText.text = $"Plant: {controller.CurrentPlant}";
        iterationInput.text = controller.iterations.ToString();
        angleInput.text = controller.CurrentAngle.ToString("F2");
        randomAngleInput.text = controller.randomAngleRange.ToString("F2");
        stepInput.text = controller.stepScale.ToString("F2");
    }

    public void ApplyChanges()
    {
        if (controller == null) return;

        if (int.TryParse(iterationInput.text, out int iter))
            controller.iterations = iter;

        if (float.TryParse(angleInput.text, out float ang))
            controller.angleOffset = ang - controller.BaseAngle;

        if (float.TryParse(randomAngleInput.text, out float ra))
            controller.randomAngleRange = Mathf.Max(0, ra);

        if (float.TryParse(stepInput.text, out float st))
            controller.stepScale = st;

        controller.Redraw();
        RefreshUI();
    }
}
